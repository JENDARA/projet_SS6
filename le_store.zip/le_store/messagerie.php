<!DOCTYPE html>


<html lang="en">
<head>
  <title>Le Store</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <link rel="stylesheet" type="text/css" href="css/responsive.css">
      <link rel="stylesheet" type="text/css" href="css1/style.css">
<?php 
 	$s="select * from messagerie ";
   echo $s;
   //pour implementer la table se compose $quantite=echo $_SESSION['panier'][0][3];
   //$prix_com=$_GET['id_cpt'];
   // $rep = $bdd->query($s);
?>
</head>
<body>

</body>

</html>